// P5JS Studio 原创示例 · MIT。极坐标粒子环，轻触改变配色。
let hueShift = 0;
const palette = ['#ff77ac','#f78dd4','#cba1ff','#91adff','#73c8f4','#66e0dc','#86e2b1','#cbe394','#f5d58d','#ffac8c','#f89dce','#a9b8ff'];
function setup() { createCanvas(windowWidth, windowHeight); pixelDensity(1.5); }
function draw() {
  background(14, 19, 29);
  const t = millis() * 0.00035, radius = min(width, height) * 0.32, context = drawingContext;
  for (let group = 0; group < palette.length; group++) {
    context.fillStyle = palette[(group + hueShift) % palette.length]; context.beginPath();
    for (let i = group; i < 720; i += palette.length) {
      const a = i * 2.399963 + t, wave = sin(i * 0.43 + t * 3) * 0.055 + sin(i * 0.17 - t) * 0.08;
      const r = radius * (1 + wave), x = width / 2 + cos(a) * r, y = height / 2 + sin(a) * r * (0.86 + 0.08 * sin(t));
      const size = 0.7 + (i % 5) * 0.22; context.moveTo(x + size, y); context.arc(x, y, size, 0, TWO_PI);
    }
    context.fill();
  }
}
function changePalette() { hueShift = (hueShift + 3) % palette.length; }
function mousePressed() { changePalette(); }
function touchStarted() { changePalette(); return false; }
function windowResized() { resizeCanvas(windowWidth, windowHeight); }
